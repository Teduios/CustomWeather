//
//  CWSuggestion.swift
//  CustomWeather
//
//  Created by hzxsdz0045 on 16/1/4.
//  Copyright © 2016年 蓦然回首love. All rights reserved.
//

import UIKit

class CWSuggestion: NSObject {
    var comf = [String: AnyObject]()
    var cw = [String: AnyObject]()
    var drsg = [String: AnyObject]()
    var flu = [String: AnyObject]()
    var sport = [String: AnyObject]()
    var trav = [String: AnyObject]()
    var uv = [String: AnyObject]()
    
}
