//
//  CWCityGroups.swift
//  CustomWeather
//
//  Created by hzxsdz0045 on 16/1/5.
//  Copyright © 2016年 SSF. All rights reserved.
//

import UIKit

class CWCityGroups: NSObject {
    var title: AnyObject?//字符串
    var cities: AnyObject?//数组
}
