//
//  AppDelegate.swift
//  CustomWeather
//
//  Created by 蓦然回首love on 16/1/3.
//  Copyright © 2016年 蓦然回首love. All rights reserved.
//

import UIKit

@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    var manager: BMKMapManager?
    var allDaysWeather = [[String:[CWCityDailyWeather]]]()
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        let bar = UINavigationBar.appearance()
        bar.barStyle = .Black
     
        manager = BMKMapManager()
        if(manager!.start("MfZnoetCi9xSs6kG6tIaHypE", generalDelegate: nil)) {
         print("授权成功!")
        }else {
         print("授权失败")
        }
        //初始化分享ssdk
        ShareSDK.registerApp("iOS_Weather",
            activePlatforms: [SSDKPlatformType.TypeSinaWeibo.rawValue],
            onImport: { (platform:SSDKPlatformType) -> Void in
               
            }) { (platform:SSDKPlatformType, appInfo: NSMutableDictionary!) -> Void in
                switch platform {
                case SSDKPlatformType.TypeSinaWeibo:
                    appInfo.SSDKSetupSinaWeiboByAppKey("1581236235",
                        appSecret : "fbe6b6798a0844e2bca463aacaed5dc0",
                        redirectUri : "http://www.sharesdk.cn",
                        authType : SSDKAuthTypeBoth)
                default:
                    break
}
        }
        // Override point for customization after application launch.
        return true
    }

    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

